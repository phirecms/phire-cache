<?php

namespace Phire\Cache\Event;

use Phire\Controller\AbstractController;
use Pop\Application;

class Cache
{

    /**
     * Bootstrap the module
     *
     * @param  Application $application
     * @return void
     */
    public static function bootstrap(Application $application)
    {

    }

}
